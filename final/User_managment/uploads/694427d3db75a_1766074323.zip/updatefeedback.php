<?php
session_start();
header('Content-Type: application/json');

$input=json_decode(file_get_contents('php://input'),true);

if(!isset($input['id'], $input['message'])){
 echo json_encode(['success'=>false,'message'=>'Missing fields']);
 exit;
}

foreach($_SESSION['feedback_data'] as &$fb){
    if($fb['id']===$input['id']){
        $fb['message']=$input['message'];
        echo json_encode(['success'=>true,'data'=>$fb]);
        exit;
    }
}
echo json_encode(['success'=>false,'message'=>'Not found']);
