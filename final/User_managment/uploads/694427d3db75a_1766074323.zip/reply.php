<?php
session_start();
header('Content-Type: application/json');

$input=json_decode(file_get_contents('php://input'),true);

if(!isset($input['id'], $input['reply'])) {
 echo json_encode(['success'=>false,'message'=>'Missing fields']);
 exit;
}

$username=$_SESSION['username']??'Anonymous';

foreach($_SESSION['feedback_data'] as &$fb){
    if($fb['id']===$input['id']){
        $fb['replies'][]=[
          'author'=>$username,
          'message'=>$input['reply'],
          'date'=>date('Y-m-d H:i:s')
        ];
        echo json_encode(['success'=>true,'data'=>$fb]);
        exit;
    }
}
echo json_encode(['success'=>false,'message'=>'Not found']);
