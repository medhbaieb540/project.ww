<?php
session_start();
header('Content-Type: application/json');

$input=json_decode(file_get_contents('php://input'),true);

if(!isset($input['id'])){
 echo json_encode(['success'=>false,'message'=>'Missing id']);
 exit;
}

foreach($_SESSION['feedback_data'] as $k=>$fb){
    if($fb['id']===$input['id']){
        unset($_SESSION['feedback_data'][$k]);
        echo json_encode(['success'=>true]);
        exit;
    }
}
echo json_encode(['success'=>false,'message'=>'Not found']);
