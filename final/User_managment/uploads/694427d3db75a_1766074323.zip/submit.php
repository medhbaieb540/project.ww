<?php
session_start();
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['game'], $input['type'], $input['message'])) {
    echo json_encode(['success'=>false,'message'=>'Missing fields']);
    exit;
}

$username = $_SESSION['username'] ?? 'Anonymous';

$new = [
  'id'=>uniqid(),
  'game'=>$input['game'],
  'type'=>$input['type'],
  'message'=>$input['message'],
  'author'=>$username,
  'date'=>date('Y-m-d H:i:s'),
  'replies'=>[]
];

$_SESSION['feedback_data'][] = $new;

echo json_encode(['success'=>true,'data'=>$new]);
